class Product:
    def __init__(self, product_name, price, quantity_in_stock):
        self.product_name = product_name
        self.price = price
        self.quantity_in_stock = quantity_in_stock

    def display_product_info(self):
        print(f"Product Name: {self.product_name}, "
              f"Price: UGX{self.price:.2f}, "
              f"Quantity in Stock: {self.quantity_in_stock}")

class ShoppingCart:
    def __init__(self):
        self.items = []

    def add_item(self, product, qty):
        if qty <= product.quantity_in_stock:
            self.items.append((product, qty))
            product.quantity_in_stock -= qty
            print(f"Added {qty} of {product.product_name} to the cart.")
        else:
            print(f"Not enough {product.product_name} in stock to add {qty}.")

    def remove_item(self, product_name):
        for item in self.items:
            if item[0].product_name == product_name:
                self.items.remove(item)
                item[0].quantity_in_stock += item[1] 
                print(f"Removed {product_name} from the cart.")
                return
        print(f"{product_name} not found in the cart.")

    def calculate_total(self):
        total = sum(product.price * qty for product, qty in self.items)
        return total

    def display_cart(self):
        if not self.items:
            print("Shopping cart is empty.")
            return
        print("Items in the cart:")
        for product, qty in self.items:
            print(f"{product.product_name}: {qty} @ UGX{product.price:.2f} each")
        print(f"Total Amount Due: UGX{self.calculate_total():.2f}")


if __name__ == "__main__":
   
    product1 = Product("baby_oil", 1000,23000)
    product2 = Product("lato", 2000, 5000)
    product3 = Product("cookies", 5000, 4500)


    print("Available Products:")
    product1.display_product_info()
    product2.display_product_info()
    product3.display_product_info()
    print()

    cart = ShoppingCart()

    cart.add_item(product1, 10)
    cart.add_item(product2, 20)
    cart.add_item(product3, 50)

    cart.display_cart()

    cart.remove_item("Orange")
    print("\nUpdated Items in Cart after removing Orange:")
    cart.display_cart()
