class BankAccount:
    
    interest_rate = 0.05  
    def __init__(self, account_holder):
        self.account_holder = account_holder
        self.balance = 0  

    def deposit(self, amount):
        if amount > 0:
            self.balance += amount
            print(f"Deposited UGX{amount}. New balance: UGX{self.balance:.2f}")
        else:
            print("Invalid deposit amount. Must be greater than zero.")

    def withdraw(self, amount):
        if amount > 0:
            if amount <= self.balance:
                self.balance -= amount
                print(f"Withdrew UGX{amount}. New balance: UGX{self.balance:.2f}")
            else:
                print("Insufficient balance for withdrawal.")
        else:
            print("Invalid withdrawal amount. Must be greater than zero.")

    def apply_interest(self):
        interest = self.balance * BankAccount.interest_rate
        self.balance += interest
        print(f"Applied interest of UGX{interest:.2f}. New balance: UGX{self.balance:.2f}")

   
    def display_account_info(self):
        print(f"Account Holder: {self.account_holder}")
        print(f"Balance: UGX{self.balance:.2f}")

account1 = BankAccount("drey")
account2 = BankAccount("aspas")

account1.deposit(30000)
account1.withdraw(47000)

account2.deposit(230000)
account2.withdraw(120000)

account1.apply_interest()
account2.apply_interest()

account1.display_account_info()
account2.display_account_info()
a

